package com.backend.projetopi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetopiApplicationTests {

	@Test
	void contextLoads() {
	}

}
